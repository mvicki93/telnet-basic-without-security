#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include <arpa/inet.h>
#include <fcntl.h> // for open
#include <unistd.h> // for close
#include<pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

#define TRUE 1
#define FAIL -1
#define RETURN_FAILURE -1
#define RETURN_SUCCESS 1

typedef struct client_info {
	int sockfd;
	char *envptr;
}clntdata_t;

struct req_data {
	unsigned int size;
	char data[0];
};

typedef struct {
	char *name;           /* User printable name of the function. */
	int (*process)(clntdata_t *, struct req_data **reply_data, char *);       /* Function to call to do the job. */
	char **argv;          /* feature use */
	char *doc;            /* Documentation for this function.  */
} builtins_t;


extern char **environ;

/*declarion*/

static int bye_wrapper (clntdata_t *client_data, struct req_data **reply_data, char *cli);
static int ls_wrapper (clntdata_t *client_data, struct req_data **reply_data, char *cli);
static int cd_wrapper(clntdata_t *client_data, struct req_data **reply_data, char *cli);
static int get_pwd(clntdata_t *client_data, struct req_data **reply_data, char *cli);

builtins_t builtin_cmds[] = {
	{ "ls", ls_wrapper, NULL, "List directory contents" },
	{ "bye", bye_wrapper, NULL, "close connection" },
	{ "cd", cd_wrapper, NULL, "Change current working directory"},
	{ "pwd", get_pwd, NULL, "Print the current working directory" },
	{NULL, NULL, NULL, NULL}
};

/*
 * sendto_client
 * send requested data to client
 */
static int
sendto_client(int socket, struct req_data *reply_data)
{
	int retval = -1;
	size_t nbytes = 0;
	char *data_out = NULL;

	do {
		if ((socket < 0) || (reply_data == NULL)) {
			printf("Sendto_Client: invalid args recvd !!!");
			retval = RETURN_FAILURE;
			break;
		}
#ifdef DEBUG
		printf("Sendto_Client: len of data in [%ld] bytes\n", nbytes);
#endif
#ifdef DEBUG
		printf("Sendto_Client: Data OUT [%s]\n", data_out);
#endif
		if (reply_data->size != 0) {
			nbytes = send(socket, reply_data, reply_data->size, 0 );
			if ( nbytes < 0 ) {
				perror("Sendto_Client: send() failed ");
				retval = RETURN_FAILURE;
				break;
			}
		}
#ifdef DEBUG
		printf("Sendto_Client: Written [%ld] bytes\n", nbytes);
#endif
		retval = RETURN_SUCCESS;
	} while(0);

	memset(reply_data->data, 0, PIPE_BUF);
	return retval;
}

/*
 * isFileExistsStats
 * check particular directory there or not
 */

static int
isFileExistsStats(const char *path)
{
	struct stat stats;


	// Check for file existence
	if (stat(path, &stats) == 0 && S_ISDIR(stats.st_mode)) {
		printf("file is available\n");
		return 1;
	}

	return 0;
}

/*
 * get_file_path
 * get file path from cd "path" command
 */
static char *
get_file_path(char *cli)
{

	while (*cli != '\0') {
		if (*cli ==' ') {
			cli++;
			break;
		}
		cli++;
	}
	return cli;
}

/*
 * remove_newline
 * remove new line from string
 */
static char *
remove_newline(char *str)
{
	char *tmp = str;

	while (*str != '\0') {
		if (*str == '\n')
			*str = '\0';
		str++;
	}

	return tmp;

}

static int
bye_wrapper (clntdata_t *client_data, struct req_data **reply_data, char *cli)
{
	printf("Thank you\n");
	printf("start cleaning process for thread id %lu\n", (unsigned long)pthread_self());

	close(client_data->sockfd);
	printf("close client socket ......\n");
	free(client_data->envptr);
	printf("freed envptr .....\n");
	free(*reply_data);
	printf("freed reply data .......\n");
	free(client_data);
	printf("freed client data ......\n");
	printf(".................\n");
	printf("thread exited id %lu\n", (unsigned long)pthread_self());
	pthread_exit(NULL);

}
/*
 * ls_wrapper
 * get all directory file and fill in to the buffer
 */
static int
ls_wrapper (clntdata_t *client_data, struct req_data **reply_data, char *cli)
{

	printf("called ls wrapper\n");    
	DIR *dr = NULL;
	char *tmep_buf = NULL;
	struct dirent *de = NULL;
	char *file_type;
	struct tm * timeinfo; // or gmtime() depending on what you want

	tmep_buf = calloc(sizeof *tmep_buf, PIPE_BUF);
	if (tmep_buf == NULL) {
		printf("malloc faild\n");
		return FAIL;
	}
	dr = opendir(client_data->envptr);
	if (dr == NULL)  // opendir returns NULL if couldn't open directory
	{
		printf("Could not open current directory" );
		free(tmep_buf);
		return 0;
	}


	while ((de = readdir(dr)) != NULL) {
		struct stat stats;
		stat(de->d_name, &stats);
		file_type = S_ISDIR(stats.st_mode) ? "D" : "F";
		timeinfo = localtime(&stats.st_birthtime); 
		sprintf(tmep_buf, "type: %s time: %s name:%s\n", file_type,
				remove_newline(asctime(timeinfo)), de->d_name);
		strcat((*reply_data)->data, tmep_buf);
		memset(tmep_buf, 0, PIPE_BUF);

	}
#ifdef DEBUG
	printf("vicki strlen %ld\n", strlen((*reply_data)->data));
	printf("vicki.........%s\n", (*reply_data)->data);
#endif

	(*reply_data)->size = strlen((*reply_data)->data) + 5;
	free(tmep_buf);
	closedir(dr);
	return TRUE;

}

static int
get_sub_str_count (char *path)
{
	int count = 0;
	const char *tmp = path;
	while((tmp = strstr(tmp, "..")))
	{
		count++;
		tmp++;
	}
	return count;
}

/*
 * cd_wrapper
 * changing the directory (its logically change the pwd)
 */
static int
cd_wrapper(clntdata_t *client_data, struct req_data **reply_data, char *cli)
{

	printf("called cd_wrapper\n");
	char *path, count = 0, *backup, *temp;
	char *abs_path = client_data->envptr;
	char ab_path[PATH_MAX] = {0};

	/* get file path*/
	path = get_file_path(cli);
#ifdef DEBUG
	printf("%s path\n", path);
#endif
	if (*path == '\0') {
		strcpy(ab_path, "/");
		path = ab_path;
		goto end;
	}else if (*path == '.' && *(path + 1) == '/') {
		strcpy(ab_path, client_data->envptr);
		strcat(ab_path, path + 1);
		path = ab_path;
		goto end;
	}else if (*path == '.' && *(path + 1) == '\0') {
		strcpy(ab_path, client_data->envptr);
		path = ab_path;
		goto end;
	}else if(*path != '\0' && *path != '.' && *path != '/') {
		strcpy(ab_path, client_data->envptr);
		temp = ab_path;

		while (*temp != '\0') {
			temp++;
		}
		if (*--temp != '/') {
			temp++;
			*temp = '/';
			*++temp = '\0';
		}

		strcat(ab_path, path);
		path = ab_path;
		goto end;
	}
#ifdef DEBUG
	printf("%s full paht %s ab_path\n", path, ab_path);
#endif
	/* validate double dot*/
	backup = abs_path;
	backup = backup + (strlen(abs_path) - 1);
	count = get_sub_str_count(path);
	printf("count %d\n", count);
	if (count != 0)  {
		while (count) {
			if (backup == abs_path) {
				path = "/"; //reached root
				break;
			}
			while (*backup != '/') {
				backup--;
			}
			count--;
			backup--;

		}
		backup++;
		if (backup == abs_path) {
			*(backup + 1) = '\0';
		}
		if (backup != abs_path)
			*backup = '\0';
		memset(ab_path, 0, PATH_MAX);
		strcpy(ab_path, client_data->envptr);
		path = ab_path;
	}
#ifdef DEBUG
	printf("%s after ..full paht\n", abs_path);
#endif
	if (!isFileExistsStats(path)) {
		strcpy((*reply_data)->data, "not found");
		(*reply_data)->size = strlen("not found") + 5;
		return RETURN_FAILURE;

	}
end:
	memset(client_data->envptr, 0, PATH_MAX); //need to take old path backup

	strncpy(client_data->envptr, path,  strlen(path));
	printf("sucess\n");
	(*reply_data)->size = 0; 
	return RETURN_SUCCESS;
}

/*
 * get pwd
 * get current working directory
 */
static int
get_pwd(clntdata_t *client_data, struct req_data **reply_data, char *cli) 
{
	printf("called getpwd\n");
	if (client_data == NULL || reply_data == NULL)
		return FAIL;

	strcpy((*reply_data)->data, client_data->envptr);
#ifdef DEBUG
	printf("pwd data %s %d\n", (*reply_data)->data, strlen((*reply_data)->data));
#endif
	(*reply_data)->size = strlen(client_data->envptr) + 5;
	return RETURN_SUCCESS;
}


static int
strcmp_space(char *src, char* dst)
{

	while (*src != '\0') {
		if (*src ==' ')
			break;
		if (*src != *dst)
			return -1;
		src++;
		dst++;
	}
	return 0;
}

static builtins_t *
is_valid_cmd(char *cmd)
{
	char i = 0;

	while (builtin_cmds[i].name != NULL) {
		if (strcmp_space(cmd, builtin_cmds[i].name) == 0) {
			return &builtin_cmds[i];
		}
		i++;

	}
	return NULL;

}

static char 
handle_client_req (char *cli_cmd, struct req_data **reply_data, clntdata_t *client_info)
{
	builtins_t *command;

	if (cli_cmd == NULL || reply_data  == NULL || client_info == NULL)
		return FAIL;
	command = is_valid_cmd(cli_cmd);

	if (command == NULL) {
		strcpy((*reply_data)->data, "not a vlid command");
		(*reply_data)->size = strlen("not a vlid command") + 5;
		return FAIL;
	}
	command->process(client_info, reply_data, cli_cmd);
	return RETURN_SUCCESS;          

}

void  *
worker_thread (void *arg)

{

	char buffer[PATH_MAX];
	char output[PIPE_BUF];
	struct req_data *reply_data;
	char cwd[PATH_MAX];
	unsigned int nbytes;

	clntdata_t *clntinfo= arg;
	clntinfo->envptr = malloc(PATH_MAX);

	if (getcwd(cwd, sizeof(cwd)) != NULL) {
		printf("Current working dir: %s\n", cwd);
	} else {
		perror("getcwd() error");
	}
	if (clntinfo->envptr == NULL) {
		printf("malloc faild\n");
		exit(1);
	} 
	strncpy(clntinfo->envptr, cwd, strlen(cwd));

	reply_data = calloc(sizeof(struct req_data), PIPE_BUF);
	if (reply_data == NULL) {
		printf("malloc faild for reply data\n");
		free(clntinfo->envptr);
		exit(1);
		//return;
	}

	while(TRUE)
	{
		memset(buffer, 0x0, sizeof buffer);
		nbytes = recv(clntinfo->sockfd, buffer, sizeof(buffer), 0);
		if (nbytes == 0) {
			printf("NULL Input.");
			break;
		} else if (nbytes == -1) {
			perror("Socket recv() failed");
			//close(socket);
			close(clntinfo->sockfd);
			free(clntinfo->envptr);
			free(reply_data);
			free(clntinfo);
			pthread_exit(NULL);
		}

		buffer[nbytes] = '\0'; //set the string terminating NULL byte at end of the data read

		printf("\n======================================================\n");

		/* Serving client needs */
#ifdef DEBUG_READ_REQUEST
		printf("Recv tid [%d] nbytes [%d] buffer [%s] \n",(int)pthread_self(), nbytes, buffer);
#endif
		memset(output, 0x0, sizeof output);
		handle_client_req(buffer, &reply_data, clntinfo);
		if (sendto_client(clntinfo->sockfd, reply_data ) == RETURN_FAILURE ) {
			printf("Error: send_client\n");
		}
		//free(reply_data);

	}

	return NULL;

}

int
main(){
	int serverSocket, newSocket;
	struct sockaddr_in serverAddr;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;
	pthread_t tid[60];
	//Create the socket. 
	serverSocket = socket(PF_INET, SOCK_STREAM, 0);

	// Configure settings of the server address struct
	// Address family = Internet 
	serverAddr.sin_family = AF_INET;

	//Set port number, using htons function to use proper byte order 
	serverAddr.sin_port = htons(54321);

	//Set IP address to localhost 
	serverAddr.sin_addr.s_addr = htonl (INADDR_ANY);//inet_addr("127.0.0.1");


	//Set all bits of the padding field to 0 
	memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);

	//Bind the address struct to the socket 
	bind(serverSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));

	//Listen on the socket, with 40 max connection requests queued 
	if(listen(serverSocket,50)==0)
		printf("Listening\n");
	else
		printf("Error\n");

	int i = 0;
	while(1)
	{
		//Accept call creates a new socket for the incoming connection
		addr_size = sizeof serverStorage;
		newSocket = accept(serverSocket, (struct sockaddr *) &serverStorage, &addr_size);
		if (newSocket == -1) {
			perror("accept faild\n");
			continue;
		}

		clntdata_t *client_env = malloc(sizeof *client_env);
		if (client_env == NULL) {
			printf("malloc faild\n");
			continue;
		}
		client_env->sockfd = newSocket; 
		//so the main thread can entertain next request
		if(pthread_create(&tid[i++], NULL, worker_thread, client_env) != 0 ) {
			close(serverSocket);
			free(client_env);
			printf("Failed to create thread\n");
		}

	}
}
