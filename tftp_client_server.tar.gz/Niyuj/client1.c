#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>  /* read, close */
#include <limits.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> /* inet_addr */
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <ctype.h>
#include <fcntl.h>

#define PORT 54321
#define RETURN_FAILURE -1
#define RETURN_SUCCESS 1


#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

char supported_cmd[][5] = {"pwd", "ls",  "cd", "bye", };

struct req_data {
	unsigned int size;
	char data[0];
};

int sockfd = -1;
const char *server_addr_global;


/*
 * void strip_extra_spaces
 * remove extra whilte space
 */
void 
strip_extra_spaces(char* str) {
	int i, x;
	for(i=x=0; str[i]; ++i)
		if(!isspace(str[i]) || (i > 0 && !isspace(str[i-1])))
			str[x++] = str[i];
	str[x] = '\0';
}

/* 
 * get_cmdline
 * read command from user
 */
	char *
get_cmdline()
{
	char *retval = NULL;
	static char *tmpline = NULL;
	static char *line_read = NULL;
	static char prompt[LINE_MAX] = {0};	

	do {
		/* Frame prompt string */
		memset(prompt, 0x00, sizeof prompt);
		sprintf(prompt,
				ANSI_COLOR_GREEN "%s" ANSI_COLOR_CYAN "@" ANSI_COLOR_BLUE "%s" ANSI_COLOR_MAGENTA "# " ANSI_COLOR_RESET,
				getenv("USER"), server_addr_global);

		if (line_read != NULL) { /* free heap mmry if already allocated by realine () */
#ifdef DEBUG_CMDLINE
			printf("free existing heap memory allocated by realine () [%p]\n", line_read);
#endif
			free(line_read);
			line_read = NULL;
		}

		/* Get a command line from the user */
		line_read = readline (prompt); /* returns pointer to heap mmry */
		if (line_read == NULL || *line_read == EOF)
			return NULL; 

#ifdef DEBUG_CMDLINE
		printf("readline return line_read ptr [%p]\n", line_read);
#endif
		tmpline = NULL;
		strip_extra_spaces(line_read);//stripwhite(line_read); /* got valid str in heap mmry */
		tmpline = line_read;
		//printf("%s templine\n", tmpline);
#ifdef DEBUG_CMDLINE
		printf("stripwhite return tmpline [%p] [%s]\n", tmpline, tmpline);
#endif

		if (tmpline && *tmpline) {
			add_history (tmpline); /* save command line to the history. equivalent to BASH_HISTORY */

		}
		retval = tmpline;

	} while (0);
#ifdef DEBUG_CMDLINE
	printf("cmd %s\n", retval);
#endif

	return retval;
}

/*
 * connect_server
 * create socket connection to server
 */
	int
connect_server(char const *server_addr, struct sockaddr_in serv_addr)
{
	int retval = RETURN_SUCCESS;

	do {
		if (server_addr == NULL) {
			printf("Connect_server: Invalid args !!!");
			retval = RETURN_FAILURE;
			break;
		}

		printf("\n=========================================================\n");
		printf("Connecting ...\n");

		if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			printf("\n Socket creation error !!!\n");
			retval = RETURN_FAILURE;
			break;
		}

		memset(&serv_addr, 0x00, sizeof(serv_addr));

		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(PORT);
		serv_addr.sin_addr.s_addr=inet_addr(server_addr);

		if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
		{
			printf("\nConnection Failed !!!\n");
			retval = RETURN_FAILURE;
			break;
		}

		retval = sockfd; /* Returns socket */
		printf("\nConnected to %s:%d \n", server_addr, PORT);
		printf("=========================================================\n");
	} while (0);

	return retval;
}

/*
 * static int strcmp_space()
 * compare string upto space
 */
static int strcmp_space(char *src, char* dst)
{
	//printf("%s src\n", dst);
	while (*src != '\0') {
		if (*src == ' ')
			break;
		if (*src != *dst)
			return -1;
		src++;
		dst++;
		//printf("kk\n");
	}
	return 0;
}

/*
 * validate_cmd
 * check given command valid or not
 */
static int 
validate_cmd(char *cli_cmd) {

	/* get data before ' '*/
	char i = 0;
	if (cli_cmd == NULL)
		return RETURN_FAILURE;
	if (strlen(cli_cmd) < 2)
		return RETURN_FAILURE;
	while (i <=  3) {
		//printf("%s clicmd \n", cli_cmd);
		if (strcmp_space(cli_cmd, supported_cmd[i]) == 0)
			return RETURN_SUCCESS;
		i++;
	}
	return RETURN_FAILURE;
}

/*
 * send_cmd_and_receive
 * send clint request command to server and receive server reply
 */
	static int
send_cmd_and_receive(char *cli_cmd, struct req_data *dataout/*char *dataout*/)
{
	int retval = RETURN_SUCCESS, ret;
	unsigned int size = 0;
	do {
		if (dataout == NULL) {
			retval =  RETURN_FAILURE;
			break;
		}

		if (cli_cmd == NULL) {
			retval =  RETURN_FAILURE;
			break;
		}
		//printf("%s cmdd\n", cli_cmd);
		if (strlen(cli_cmd) < 2) {
			retval =  RETURN_FAILURE;
			break;
		}

		if (validate_cmd(cli_cmd) == RETURN_FAILURE) {
#if 1
			printf("currently not supporting this command\n");
#endif
			retval = RETURN_FAILURE;
			break;
		}

		if (send(sockfd, cli_cmd, strlen(cli_cmd), 0 ) < 0) {
#ifdef DEBUG_CMDLINE
			printf("transceiver: send failed !!!\n");
#endif
			retval = RETURN_FAILURE;
			break;
		}
		fcntl(sockfd, F_SETFL, O_NONBLOCK);
		sleep(1);

		/*
		 * get size of the reply data 
		 */  
		if((ret = recv(sockfd, &size, 4, 0))) {
			if (ret < 0) {
#ifdef DEBUG_CMDLINE
				printf("transceiver: recv failed !!!");
#endif
				retval = RETURN_FAILURE;
				break;
			}
		}
		if (ret == 0)
			exit(1);               
		dataout->size = size;
#ifdef DEBUG_CMDLINE
		//printf("size ...%ld\n", size);
#endif      
		if((ret = recv(sockfd, dataout->data, size, 0)))
		{
			if (ret < 0) {
#ifdef DEBUG_CMDLINE
				printf("transceiver: recv failed !!!");
#endif
				retval = RETURN_FAILURE;
				break;
			}

			printf("%s\n", dataout->data);
		}
		if (ret == 0)
			exit(1);               
		//printf("%s\n", dataout);
		memset(dataout->data, 0, PIPE_BUF);

	}while(0);

	return retval; 
}

/*
 * cmdline_input_handler
 * Handle command line input
 */
	static struct req_data *
cmdline_input_handler(char *cli_cmd)
{
	//char *buffer = calloc(sizeof(char), PIPE_BUF);
	struct req_data *buffer = calloc(sizeof *buffer, PIPE_BUF);
	if (buffer == NULL) {
		printf("malloc faild for receive data\n");
		return NULL;
	}
	do {
		if (cli_cmd == NULL) {
			printf("clihandler: invalid args !!!\n");
			free(buffer);
			buffer = NULL;
			break;
		}
		if (send_cmd_and_receive(cli_cmd, buffer) == RETURN_FAILURE) {
#ifdef DEBUG_CMDLINE
			printf("clihandler: send and receive faild !!!\n");
#endif
			free(buffer);
			buffer = NULL;
			break;
		}

	}while(0);
	return buffer;
}


	int
main(int argc, char const *argv[])
{
	int pid = -1;
	int retval = -1;
	int isocket = -1;
	char const *server_addr = NULL;
	struct sockaddr_in serv_addr;
	char *cmdlineptr = NULL;
	char *receive_buffer = NULL;
#ifdef LOCAL_MACHINE
	server_addr = "127.0.0.1";
#else
	if (argc < 2) {
		printf("usage: client.out <server ip address>\n");
		exit(1);
	}

	server_addr = argv[1];
#endif

	isocket = connect_server(server_addr, serv_addr);
	if (isocket < 0) {
		printf("\nFailed to connect server: %s %d !!!\n\n", server_addr, PORT);
		return -1;
	}
	server_addr_global = server_addr;
	//system("clear"); /* clear command prompt screen */

	while(1) {
		cmdlineptr = NULL;
		/* Getting Client side cli_cmd */
		cmdlineptr = get_cmdline();
		if (cmdlineptr == NULL) { /* Hit on empty input line or error */
			continue;
		}

		/* Validate and Execute Commands */

		receive_buffer = (char *)cmdline_input_handler(cmdlineptr);
		if (receive_buffer == NULL) {
#ifdef DEBUG_CMDLINE
			printf("exec failed !!!\n");
#endif
			continue;
		}
		/* print reveive data*/

		free(receive_buffer);

	}

	close(isocket);
	return 0;
}

